
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  Plus, 
  Leaf, 
  ThermometerSun, 
  Droplets, 
  Scissors, 
  Camera, 
  Search, 
  ChevronRight, 
  Calendar,
  AlertCircle,
  X,
  CheckCircle2,
  Trash2,
  ChevronDown,
  Sprout,
  Bug,
  Info,
  History,
  Clock,
  ListChecks,
  ArrowRight,
  ImagePlus,
  Heart,
  CalendarDays
} from 'lucide-react';
import { Plant, PlantCategory, DiagnosticResult, PlantCondition } from './types';
import { INITIAL_PLANTS, AUCKLAND_MONTHLY_GUIDE } from './constants';
import { diagnosePlantHealth } from './services/geminiService';

const App: React.FC = () => {
  const [plants, setPlants] = useState<Plant[]>(() => {
    const saved = localStorage.getItem('auckland_garden_plants_v3');
    return saved ? JSON.parse(saved) : INITIAL_PLANTS;
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'garden' | 'diagnose' | 'calendar'>('garden');
  const [selectedCategory, setSelectedCategory] = useState<PlantCategory | 'All'>('All');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedPlantId, setSelectedPlantId] = useState<string | null>(null);
  const [isDiagnosing, setIsDiagnosing] = useState(false);
  const [diagnosticResult, setDiagnosticResult] = useState<DiagnosticResult | null>(null);
  const [tempImage, setTempImage] = useState<string | null>(null);
  const [addPlantImage, setAddPlantImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const addImageRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    localStorage.setItem('auckland_garden_plants_v3', JSON.stringify(plants));
  }, [plants]);

  const currentMonth = new Date().getMonth();
  const selectedMonthIndex = currentMonth;
  const selectedMonthData = AUCKLAND_MONTHLY_GUIDE[selectedMonthIndex];

  const filteredPlants = plants.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         p.variety?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = selectedCategory === 'All' || p.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const selectedPlant = useMemo(() => plants.find(p => p.id === selectedPlantId), [plants, selectedPlantId]);

  const myGardenTasks = useMemo(() => {
    const taskMap: Record<string, { plantNames: string[], advice: string }> = {};
    const monthData = AUCKLAND_MONTHLY_GUIDE[selectedMonthIndex];

    plants.forEach(p => {
      let key = '';
      let advice = '';
      if (p.name.toLowerCase().includes('citrus') || p.name.toLowerCase().includes('lemon') || p.name.toLowerCase().includes('mandarin')) {
        key = 'Citrus Care';
        advice = `Focus: ${monthData.watering.includes('Citrus') ? 'Watering' : 'Nutrition'}. ${monthData.pests.includes('Citrus') ? 'Check for Pests.' : ''}`;
      } else if (p.name.toLowerCase().includes('rose')) {
        key = 'Rose Care';
        advice = monthData.pruning.includes('Rose') ? 'Pruning required.' : 'Maintenance and Deadheading.';
      } else if (p.name.toLowerCase().includes('nectarine') || p.name.toLowerCase().includes('plum') || p.name.toLowerCase().includes('cherry')) {
        key = 'Stone Fruit Care';
        advice = monthData.pruning.includes('Stone Fruit') ? 'Major Winter Prune.' : 'Growth monitoring.';
      } else if (p.category === PlantCategory.HERB) {
        key = 'Herb Maintenance';
        advice = `Ensure soil moisture for ${p.name}. ${monthData.pruning.includes('Herb') ? 'Trim back now.' : ''}`;
      } else {
        key = 'General Ornamental';
        advice = `Check ${p.name} for seasonal resilience.`;
      }
      if (!taskMap[key]) taskMap[key] = { plantNames: [], advice };
      if (!taskMap[key].plantNames.includes(p.name)) taskMap[key].plantNames.push(p.name);
    });
    return Object.entries(taskMap).map(([title, data]) => ({ title, ...data }));
  }, [plants, selectedMonthIndex]);

  const handleAddPlant = (newPlant: Partial<Plant>) => {
    const plant: Plant = {
      id: Date.now().toString(),
      name: newPlant.name || 'Unnamed Plant',
      variety: newPlant.variety || '',
      category: newPlant.category || PlantCategory.ORNAMENTAL,
      dateAdded: new Date().toISOString().split('T')[0],
      imageUrl: addPlantImage || undefined,
      notes: newPlant.notes || '',
      healthHistory: [],
    };
    setPlants([plant, ...plants]);
    setAddPlantImage(null);
    setShowAddModal(false);
  };

  const deletePlant = (id: string) => {
    if (confirm('Are you sure you want to remove this plant from your garden?')) {
      setPlants(plants.filter(p => p.id !== id));
      if (selectedPlantId === id) setSelectedPlantId(null);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, target: 'diagnose' | 'add') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        if (target === 'diagnose') {
          setTempImage(result);
          runDiagnosis(result);
        } else {
          setAddPlantImage(result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const runDiagnosis = async (image: string) => {
    setIsDiagnosing(true);
    setDiagnosticResult(null);
    try {
      const result = await diagnosePlantHealth(image);
      setDiagnosticResult(result);
      
      // If we are diagnosing from a selected plant, record it in history
      if (selectedPlantId) {
        setPlants(prev => prev.map(p => {
          if (p.id === selectedPlantId) {
            return {
              ...p,
              healthHistory: [
                {
                  date: new Date().toISOString().split('T')[0],
                  condition: result.urgency === 'High' ? 'Poor' : result.urgency === 'Medium' ? 'Fair' : 'Good',
                  notes: `${result.identification}: ${result.problem}`
                },
                ...p.healthHistory
              ]
            };
          }
          return p;
        }));
      }
    } catch (error) {
      console.error(error);
      alert('Failed to analyze health. Please try again.');
    } finally {
      setIsDiagnosing(false);
    }
  };

  return (
    <div className="min-h-screen pb-32">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-emerald-600 p-2 rounded-xl shadow-lg shadow-emerald-200">
              <Leaf className="text-white w-5 h-5" />
            </div>
            <h1 className="font-black text-xl tracking-tight text-emerald-900">AucklandGarden</h1>
          </div>
          <button 
            onClick={() => setShowAddModal(true)}
            className="bg-emerald-600 hover:bg-emerald-700 text-white p-2.5 rounded-full transition-all shadow-lg shadow-emerald-200 active:scale-90"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-6">
        {/* Navigation Tabs */}
        <div className="flex bg-slate-200/50 p-1.5 rounded-[1.5rem] mb-8">
          {(['garden', 'diagnose', 'calendar'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${
                activeTab === tab 
                ? 'bg-white text-emerald-700 shadow-sm scale-[1.02]' 
                : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Garden Tab */}
        {activeTab === 'garden' && (
          <section className="space-y-6 animate-in fade-in duration-500">
            <div className="flex flex-col md:flex-row gap-4 items-center">
              <div className="relative flex-1 w-full">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Find your plants..."
                  className="w-full pl-12 pr-6 py-4 rounded-3xl bg-white border border-slate-100 shadow-sm focus:outline-none focus:ring-4 focus:ring-emerald-500/10 font-medium"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="flex gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 no-scrollbar">
                {['All', ...Object.values(PlantCategory)].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat as any)}
                    className={`whitespace-nowrap px-5 py-2.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${
                      selectedCategory === cat 
                      ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200' 
                      : 'bg-white text-slate-500 border border-slate-100'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {filteredPlants.map((plant) => (
                <div 
                  key={plant.id} 
                  className="bg-white rounded-[2rem] overflow-hidden border border-slate-100 shadow-sm hover:shadow-xl transition-all group cursor-pointer active:scale-[0.98]"
                  onClick={() => setSelectedPlantId(plant.id)}
                >
                  <div className="h-56 bg-slate-100 relative overflow-hidden">
                    {plant.imageUrl ? (
                      <img src={plant.imageUrl} alt={plant.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center text-slate-300">
                        <Leaf className="w-12 h-12 mb-2 opacity-20" />
                        <span className="text-[10px] font-black uppercase tracking-[0.2em]">No Photo</span>
                      </div>
                    )}
                    <div className="absolute top-4 left-4">
                       <span className="text-[10px] font-black uppercase tracking-widest text-emerald-700 bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-full shadow-sm">
                        {plant.category}
                      </span>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-black text-slate-900 mb-1">{plant.name}</h3>
                    <p className="text-sm text-slate-400 font-bold">{plant.variety || 'Auckland Native'}</p>
                    
                    <div className="flex items-center gap-4 mt-6">
                       <div className="flex items-center gap-1.5 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        <Droplets className="w-3.5 h-3.5 text-blue-400" />
                        <span>Care Ready</span>
                       </div>
                       <div className="flex items-center gap-1.5 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        <CalendarDays className="w-3.5 h-3.5 text-emerald-400" />
                        <span>In Schedule</span>
                       </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Diagnose Tab */}
        {activeTab === 'diagnose' && (
          <section className="animate-in fade-in duration-500 max-w-2xl mx-auto">
            <div className="bg-slate-900 rounded-[3rem] p-10 text-white shadow-2xl relative overflow-hidden mb-8">
              <div className="absolute -bottom-10 -right-10 opacity-10">
                <Heart className="w-64 h-64 text-emerald-500" />
              </div>
              <div className="relative z-10">
                <h2 className="text-4xl font-black mb-4 leading-tight">Health Hub</h2>
                <p className="text-slate-400 text-lg leading-relaxed mb-10 font-medium">
                  Scan any plant for pests, diseases, or deficiencies common in Auckland's humidity.
                </p>
                
                <input 
                  type="file" 
                  accept="image/*" 
                  className="hidden" 
                  ref={fileInputRef} 
                  onChange={(e) => handleImageUpload(e, 'diagnose')}
                />

                <button 
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isDiagnosing}
                  className="w-full bg-white text-slate-900 px-8 py-5 rounded-[2rem] font-black flex items-center justify-center gap-3 hover:bg-emerald-50 transition-all shadow-xl disabled:opacity-50 active:scale-95"
                >
                  <Camera className="w-6 h-6 text-emerald-600" />
                  {isDiagnosing ? 'Running Diagnostics...' : 'Start Health Scan'}
                </button>
              </div>
            </div>

            {isDiagnosing && (
              <div className="flex flex-col items-center justify-center py-20 space-y-6">
                <div className="w-16 h-16 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
                <div className="text-center">
                  <p className="text-slate-800 font-black text-2xl uppercase tracking-tighter">AI Analysis</p>
                  <p className="text-slate-400 font-bold">Scanning Auckland database...</p>
                </div>
              </div>
            )}

            {tempImage && !isDiagnosing && diagnosticResult && (
              <div className="bg-white rounded-[3rem] overflow-hidden border border-slate-100 shadow-2xl animate-in zoom-in-95 duration-500">
                <div className="h-80 overflow-hidden relative">
                  <img src={tempImage} alt="Plant diagnosis" className="w-full h-full object-cover" />
                </div>
                <div className="p-10">
                  <div className="flex items-center gap-3 mb-6">
                    <div className={`px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.2em] ${
                      diagnosticResult.urgency === 'High' ? 'bg-red-500 text-white' :
                      diagnosticResult.urgency === 'Medium' ? 'bg-amber-400 text-slate-900' : 'bg-emerald-500 text-white'
                    }`}>
                      {diagnosticResult.urgency} Priority
                    </div>
                    <div className="h-1.5 w-1.5 bg-slate-200 rounded-full"></div>
                    <h3 className="text-slate-800 font-black uppercase text-xs tracking-widest">{diagnosticResult.identification}</h3>
                  </div>
                  <h4 className="text-3xl font-black text-slate-900 mb-6 leading-tight">{diagnosticResult.problem}</h4>
                  <div className="bg-emerald-50 rounded-[2.5rem] p-8 border border-emerald-100 mb-8">
                    <h5 className="font-black text-emerald-900 text-xs uppercase tracking-widest mb-4 flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" /> Auckland Expert Advice
                    </h5>
                    <p className="text-emerald-900/80 leading-relaxed whitespace-pre-line text-lg font-medium">
                      {diagnosticResult.solution}
                    </p>
                  </div>
                  <button 
                    onClick={() => {setTempImage(null); setDiagnosticResult(null);}}
                    className="w-full py-5 rounded-2xl text-slate-400 font-black uppercase tracking-widest text-xs border-2 border-slate-50 hover:bg-slate-50 transition-all active:scale-[0.98]"
                  >
                    Start New Health Check
                  </button>
                </div>
              </div>
            )}
          </section>
        )}

        {/* Timeline/Calendar Tab */}
        {activeTab === 'calendar' && (
          <section className="animate-in fade-in duration-500 space-y-8">
            <div className="bg-white rounded-[2.5rem] p-4 border border-slate-100 shadow-sm overflow-hidden">
               <div className="flex overflow-x-auto no-scrollbar gap-2 px-2 py-2">
                 {AUCKLAND_MONTHLY_GUIDE.map((guide, idx) => (
                  <button
                    key={idx}
                    className={`flex flex-col items-center justify-center min-w-[80px] h-[100px] rounded-2xl transition-all ${
                      idx === currentMonth 
                      ? 'bg-emerald-600 text-white shadow-xl shadow-emerald-200 scale-105' 
                      : 'bg-slate-50 text-slate-400'
                    }`}
                  >
                    <span className="text-[10px] font-black uppercase tracking-tighter mb-1 opacity-60">
                      {idx === currentMonth ? 'NOW' : 'MONTH'}
                    </span>
                    <span className="text-xl font-black">{guide.title.split(' ')[0].substring(0, 3)}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-emerald-50 rounded-[3rem] p-10 border border-emerald-100">
              <div className="flex items-center gap-4 mb-8">
                <div className="p-3 bg-white rounded-2xl shadow-sm text-emerald-600">
                  <ListChecks className="w-6 h-6" />
                </div>
                <h3 className="text-2xl font-black text-emerald-900 uppercase tracking-widest">Auckland Action Plan</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {myGardenTasks.map((task, idx) => (
                  <div key={idx} className="bg-white p-6 rounded-[2rem] shadow-sm border border-emerald-100 hover:shadow-md transition-shadow">
                    <h4 className="font-black text-emerald-900 text-sm mb-3 uppercase tracking-widest">{task.title}</h4>
                    <div className="flex flex-wrap gap-1.5 mb-4">
                      {task.plantNames.map(pName => (
                        <span key={pName} className="text-[9px] px-2.5 py-1 bg-slate-50 text-slate-400 rounded-full font-black uppercase tracking-widest">
                          {pName}
                        </span>
                      ))}
                    </div>
                    <p className="text-sm text-slate-600 leading-relaxed font-bold flex items-start gap-2">
                      <ArrowRight className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                      {task.advice}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}
      </main>

      {/* DETAILED PLANT VIEW MODAL */}
      {selectedPlant && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/90 backdrop-blur-2xl animate-in fade-in duration-300 overflow-y-auto">
          <div className="bg-white w-full max-w-4xl rounded-[3rem] shadow-2xl animate-in zoom-in-95 duration-500 my-8 overflow-hidden">
            {/* Image Hero Section */}
            <div className="relative h-[450px] bg-slate-100">
              {selectedPlant.imageUrl ? (
                <img src={selectedPlant.imageUrl} alt={selectedPlant.name} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-slate-300">
                  <Leaf className="w-24 h-24 mb-4 opacity-10" />
                  <span className="text-xs font-black uppercase tracking-widest">Garden View</span>
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
              
              <button 
                onClick={() => setSelectedPlantId(null)} 
                className="absolute top-8 right-8 p-4 bg-white/10 backdrop-blur-md hover:bg-white/20 rounded-full transition-all text-white active:scale-90"
              >
                <X className="w-6 h-6" />
              </button>

              <div className="absolute bottom-12 left-12 right-12 text-white">
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-[10px] font-black uppercase tracking-[0.3em] bg-emerald-600 px-5 py-2 rounded-full shadow-lg">
                    {selectedPlant.category}
                  </span>
                  <span className="text-[10px] font-black uppercase tracking-[0.3em] bg-white/20 backdrop-blur-md px-5 py-2 rounded-full">
                    Auckland Zone
                  </span>
                </div>
                <h3 className="text-6xl font-black leading-none mb-3 tracking-tighter">{selectedPlant.name}</h3>
                <p className="text-xl font-bold text-white/70 italic">{selectedPlant.variety || 'Auckland Native / Hybrid'}</p>
              </div>
            </div>

            <div className="p-12 grid grid-cols-1 lg:grid-cols-12 gap-16">
              {/* Left Column: Notes & History */}
              <div className="lg:col-span-7 space-y-12">
                <section>
                  <div className="flex items-center gap-3 mb-6">
                    <Info className="w-6 h-6 text-emerald-600" />
                    <h4 className="text-sm font-black text-slate-900 uppercase tracking-widest">Plant Profile & Notes</h4>
                  </div>
                  <div className="p-8 bg-slate-50 rounded-[2.5rem] border border-slate-100 text-slate-700 leading-relaxed font-medium text-lg shadow-inner">
                    {selectedPlant.notes || 'No specific location or care notes added yet. Keep track of sun exposure and soil needs here.'}
                  </div>
                </section>

                <section>
                  <div className="flex items-center gap-3 mb-8">
                    <History className="w-6 h-6 text-emerald-600" />
                    <h4 className="text-sm font-black text-slate-900 uppercase tracking-widest">Health History</h4>
                  </div>
                  <div className="space-y-6">
                    {selectedPlant.healthHistory.length > 0 ? (
                      selectedPlant.healthHistory.map((record, i) => (
                        <div key={i} className="flex gap-6 group">
                          <div className="flex flex-col items-center">
                            <div className={`w-4 h-4 rounded-full mt-2 ring-4 ${
                              record.condition === 'Excellent' ? 'bg-emerald-500 ring-emerald-50' : 
                              record.condition === 'Good' ? 'bg-blue-400 ring-blue-50' : 
                              record.condition === 'Fair' ? 'bg-amber-400 ring-amber-50' : 'bg-red-400 ring-red-50'
                            }`}></div>
                            {i !== selectedPlant.healthHistory.length - 1 && <div className="w-0.5 h-full bg-slate-100 my-2"></div>}
                          </div>
                          <div className="pb-8 border-b border-slate-50 w-full">
                            <p className="text-[10px] font-black text-slate-400 mb-2 flex items-center gap-2 uppercase tracking-widest">
                              <Clock className="w-3.5 h-3.5" />
                              {new Date(record.date).toLocaleDateString('en-NZ', { day: 'numeric', month: 'long', year: 'numeric' })}
                            </p>
                            <p className="text-slate-900 font-black text-lg mb-1">{record.condition} Status</p>
                            <p className="text-slate-500 font-medium italic">{record.notes}</p>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="p-12 border-2 border-dashed border-slate-100 rounded-[2.5rem] text-center">
                        <Bug className="w-12 h-12 text-slate-100 mx-auto mb-4" />
                        <p className="text-slate-400 font-black uppercase tracking-widest text-xs">No health history recorded yet.</p>
                      </div>
                    )}
                  </div>
                </section>
              </div>

              {/* Right Column: Actions & Quick Care */}
              <div className="lg:col-span-5 space-y-10">
                <section className="bg-slate-900 rounded-[3rem] p-10 text-white shadow-2xl relative overflow-hidden">
                   <div className="absolute -top-10 -right-10 opacity-10">
                    <Sprout className="w-48 h-48" />
                   </div>
                   <div className="relative z-10">
                     <div className="flex items-center gap-3 mb-6 text-emerald-400">
                       <Sprout className="w-6 h-6" />
                       <h4 className="text-[10px] font-black uppercase tracking-[0.3em]">Smart Tip</h4>
                     </div>
                     <p className="text-xl leading-relaxed font-bold mb-6">
                       {selectedPlant.category === PlantCategory.FRUIT 
                         ? "Auckland's humid summers can cause powdery mildew. Ensure your plant is in a spot with great airflow and keep the roots mulched." 
                         : "Check the soil drainage. In Auckland's clay soils, raised beds or gypsum soil conditioner works wonders for this variety."}
                     </p>
                     <div className="h-px bg-white/10 w-full mb-6"></div>
                     <div className="flex items-center gap-6 text-white/60">
                        <div className="flex flex-col">
                          <span className="text-[10px] font-black uppercase mb-1">Added</span>
                          <span className="text-white font-bold">{new Date(selectedPlant.dateAdded).toLocaleDateString()}</span>
                        </div>
                        <div className="flex flex-col">
                          <span className="text-[10px] font-black uppercase mb-1">Zone</span>
                          <span className="text-white font-bold">Subtropical</span>
                        </div>
                     </div>
                   </div>
                </section>

                <div className="flex flex-col gap-4">
                  <button 
                    onClick={() => {
                      setActiveTab('diagnose');
                      setSelectedPlantId(null);
                      // In a real app we might pass the selected plant context to the diagnosis
                    }}
                    className="w-full py-6 bg-emerald-600 text-white rounded-[2rem] font-black uppercase tracking-widest text-sm shadow-xl shadow-emerald-100 active:scale-95 transition-all flex items-center justify-center gap-3"
                  >
                    <Camera className="w-5 h-5" />
                    Check Plant Health
                  </button>
                  <button 
                    onClick={() => setSelectedPlantId(null)}
                    className="w-full py-6 bg-white border-2 border-slate-100 rounded-[2rem] font-black uppercase tracking-widest text-sm text-slate-400 hover:bg-slate-50 transition-all flex items-center justify-center gap-3"
                  >
                    <ArrowRight className="w-5 h-5 rotate-180" />
                    Return to Garden
                  </button>
                  <button 
                    onClick={(e) => { e.stopPropagation(); deletePlant(selectedPlant.id); }}
                    className="w-full py-4 text-red-300 hover:text-red-500 font-black uppercase tracking-widest text-[10px] transition-all flex items-center justify-center gap-2"
                  >
                    <Trash2 className="w-4 h-4" />
                    Remove from Property
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ADD PLANT MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-slate-900/80 backdrop-blur-xl animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-lg rounded-[3rem] p-10 shadow-2xl animate-in slide-in-from-bottom-10 duration-500">
            <div className="flex justify-between items-center mb-10">
              <h3 className="text-4xl font-black text-slate-900 leading-none">New Addition</h3>
              <button onClick={() => setShowAddModal(false)} className="p-3 hover:bg-slate-100 rounded-full transition-colors">
                <X className="w-6 h-6 text-slate-400" />
              </button>
            </div>

            <form onSubmit={(e) => {
              e.preventDefault();
              const formData = new FormData(e.currentTarget);
              handleAddPlant({
                name: formData.get('name') as string,
                variety: formData.get('variety') as string,
                category: formData.get('category') as PlantCategory,
                notes: formData.get('notes') as string,
              });
            }} className="space-y-6">
              <div 
                className="h-48 bg-slate-50 border-2 border-dashed border-slate-200 rounded-[2rem] flex flex-col items-center justify-center cursor-pointer relative overflow-hidden hover:border-emerald-300 transition-colors"
                onClick={() => addImageRef.current?.click()}
              >
                {addPlantImage ? (
                  <img src={addPlantImage} className="w-full h-full object-cover" />
                ) : (
                  <>
                    <div className="p-4 bg-white rounded-2xl shadow-sm mb-4">
                      <ImagePlus className="w-8 h-8 text-emerald-500" />
                    </div>
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Capture or Upload Photo</span>
                  </>
                )}
                <input 
                  type="file" 
                  accept="image/*" 
                  className="hidden" 
                  ref={addImageRef} 
                  onChange={(e) => handleImageUpload(e, 'add')} 
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Plant Name</label>
                  <input required name="name" type="text" placeholder="e.g. Lemon Tree" className="w-full p-4 rounded-2xl bg-slate-50 border border-slate-50 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 font-bold" />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Variety</label>
                  <input name="variety" type="text" placeholder="e.g. Meyer" className="w-full p-4 rounded-2xl bg-slate-50 border border-slate-50 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 font-bold" />
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Category</label>
                <div className="relative">
                  <select name="category" className="w-full p-4 rounded-2xl bg-slate-50 border border-slate-50 focus:outline-none appearance-none font-bold cursor-pointer">
                    {Object.values(PlantCategory).map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none" />
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Location & Care Notes</label>
                <textarea name="notes" placeholder="Where is it planted? Any special needs?" className="w-full p-4 rounded-2xl bg-slate-50 border border-slate-50 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 min-h-[100px] font-bold" />
              </div>
              <button type="submit" className="w-full py-6 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-lg rounded-[2rem] shadow-2xl shadow-emerald-200 transition-all active:scale-[0.97] mt-4">
                Grow this Plant
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Bottom Navbar */}
      <nav className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-white/90 backdrop-blur-2xl border border-slate-200 px-10 py-5 flex items-center gap-12 z-40 shadow-2xl rounded-[3rem] w-[90%] max-w-md">
        <NavButton active={activeTab === 'garden'} onClick={() => setActiveTab('garden')} icon={<Leaf />} label="Garden" />
        <NavButton active={activeTab === 'diagnose'} onClick={() => setActiveTab('diagnose')} icon={<Camera />} label="Health" />
        <NavButton active={activeTab === 'calendar'} onClick={() => setActiveTab('calendar')} icon={<Calendar />} label="Timeline" />
      </nav>
    </div>
  );
};

const CareDetailCard: React.FC<{ icon: React.ReactNode; title: string; content: string }> = ({ icon, title, content }) => (
  <div className="bg-slate-50 p-8 rounded-[2rem] border border-slate-100 hover:border-emerald-200 transition-colors group">
    <div className="flex items-center gap-3 mb-4">
      <div className="p-2.5 bg-white rounded-xl shadow-sm group-hover:scale-110 transition-transform">
        {icon}
      </div>
      <h4 className="font-black text-slate-800 uppercase text-[10px] tracking-widest">{title}</h4>
    </div>
    <p className="text-sm text-slate-500 leading-relaxed font-bold italic">
      {content}
    </p>
  </div>
);

// Fix NavButton to use valid element check and permissive generic for cloneElement to avoid Partial<unknown> error
const NavButton: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string }> = ({ active, onClick, icon, label }) => (
  <button 
    onClick={onClick}
    className={`flex flex-col items-center gap-1.5 transition-all ${active ? 'text-emerald-600 scale-110' : 'text-slate-400 hover:text-slate-600'}`}
  >
    <div className={`p-3 rounded-[1.25rem] transition-all ${active ? 'bg-emerald-100 shadow-sm' : ''}`}>
      {React.isValidElement(icon) ? React.cloneElement(icon as React.ReactElement<any>, { className: 'w-6 h-6' }) : icon}
    </div>
    <span className="text-[10px] font-black uppercase tracking-widest">{label}</span>
  </button>
);

export default App;
