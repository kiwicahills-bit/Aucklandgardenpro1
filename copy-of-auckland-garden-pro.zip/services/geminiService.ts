
import { GoogleGenAI, Type } from "@google/genai";
import { DiagnosticResult } from "../types";

// Always use the process.env.API_KEY directly as per guidelines
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const diagnosePlantHealth = async (imageData: string): Promise<DiagnosticResult> => {
  const model = 'gemini-3-flash-preview';
  
  const prompt = `
    Analyze this plant image for potential pests, diseases, or nutrient deficiencies.
    Context: The garden is located in Auckland, New Zealand (Subtropical, humid climate).
    
    Common Auckland issues include: Citrus Leaf Miner, Guava Moth, Passionvine Hopper, Downy Mildew, Rust, Scale, and Aphids.
    
    Please identify the plant (if possible) and the specific problem. Provide a solution including cultural control and safe treatment.
  `;

  // Use ai.models.generateContent directly with the model name as per guidelines
  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        { inlineData: { data: imageData.split(',')[1], mimeType: 'image/jpeg' } },
        { text: prompt }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          identification: { type: Type.STRING, description: 'The name of the plant identified.' },
          problem: { type: Type.STRING, description: 'Description of the pest or disease found.' },
          solution: { type: Type.STRING, description: 'Step by step treatment and care advice for Auckland climate.' },
          urgency: { type: Type.STRING, description: 'Urgency level: Low, Medium, or High.' }
        },
        required: ['identification', 'problem', 'solution', 'urgency']
      }
    }
  });

  // Extract text property directly as it is a getter, not a method.
  return JSON.parse(response.text || '{}') as DiagnosticResult;
};

export const getSmartAdvice = async (plantName: string, category: string): Promise<string> => {
  // Use ai.models.generateContent directly with the model name as per guidelines
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Give 3 short, punchy expert tips for caring for ${plantName} (${category}) in Auckland, NZ. Focus on soil, wind protection, and local pests.`,
  });
  // Extract text property directly as it is a getter, not a method.
  return response.text || "Keep the soil well-drained and enjoy your garden!";
};
