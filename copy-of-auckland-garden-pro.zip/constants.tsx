
import { Plant, PlantCategory } from './types';

export const INITIAL_PLANTS: Plant[] = [
  { id: '1', name: 'Acacia Howittii', variety: 'Standard', category: PlantCategory.ORNAMENTAL, dateAdded: '2024-01-01', notes: 'Sticky wattle, needs light pruning.', healthHistory: [], imageUrl: 'https://images.unsplash.com/photo-1599591451000-0e7039600f75?q=80&w=1000&auto=format&fit=crop' },
  { id: '2', name: 'Mandarin', variety: 'Satsuma / Okitsu', category: PlantCategory.FRUIT, dateAdded: '2024-01-01', notes: 'Sweet seedless fruit. Auckland favorite.', healthHistory: [], imageUrl: 'https://images.unsplash.com/photo-1611080626919-7cf5a9dbab5b?q=80&w=1000&auto=format&fit=crop' },
  { id: '3', name: 'Nectarine', variety: 'Mabel', category: PlantCategory.FRUIT, dateAdded: '2024-01-01', notes: 'Stone fruit, needs winter pruning.', healthHistory: [], imageUrl: 'https://images.unsplash.com/photo-1596560670954-469082f059bc?q=80&w=1000&auto=format&fit=crop' },
  { id: '4', name: 'Plum', variety: 'Santa Rosa', category: PlantCategory.FRUIT, dateAdded: '2024-01-01', notes: 'Requires pollination partner usually.', healthHistory: [], imageUrl: 'https://images.unsplash.com/photo-1541859453910-c3ca301d9821?q=80&w=1000&auto=format&fit=crop' },
  { id: '5', name: 'Cherry', variety: 'Stella Colt', category: PlantCategory.FRUIT, dateAdded: '2024-01-01', notes: 'Self-fertile cherry.', healthHistory: [], imageUrl: 'https://images.unsplash.com/photo-1528821128474-27f963b06295?q=80&w=1000&auto=format&fit=crop' },
  { id: '6', name: 'Maple', variety: 'Acer dissectum Tameukeyama', category: PlantCategory.ORNAMENTAL, dateAdded: '2024-01-01', notes: 'Lace-leaf, deep purple.', healthHistory: [], imageUrl: 'https://images.unsplash.com/photo-1502082553048-f009c37129b9?q=80&w=1000&auto=format&fit=crop' },
  { id: '7', name: 'Yew Pine', variety: 'Podocarpus Macrophyllus', category: PlantCategory.SHRUB, dateAdded: '2024-01-01', notes: 'Very hardy screen plant.', healthHistory: [], imageUrl: 'https://images.unsplash.com/photo-1589123011449-361718870195?q=80&w=1000&auto=format&fit=crop' },
  { id: '8', name: 'Indigo', variety: 'Indigofera Decora', category: PlantCategory.ORNAMENTAL, dateAdded: '2024-01-01', notes: 'Dainty pink flowers.', healthHistory: [], imageUrl: 'https://images.unsplash.com/photo-1508704019882-f9cf40e475b4?q=80&w=1000&auto=format&fit=crop' },
  { id: '9', name: 'Lemon', variety: 'Meyer Dwarf', category: PlantCategory.FRUIT, dateAdded: '2024-01-01', notes: 'Thin skin, heavy cropper.', healthHistory: [], imageUrl: 'https://images.unsplash.com/photo-1517431783201-9487de0e59a2?q=80&w=1000&auto=format&fit=crop' },
  { id: '10', name: 'Rose', variety: 'Scentimental Floribunda', category: PlantCategory.ORNAMENTAL, dateAdded: '2024-01-01', notes: 'Striped petals, highly scented.', healthHistory: [], imageUrl: 'https://images.unsplash.com/photo-1496062031456-07b8f162a322?q=80&w=1000&auto=format&fit=crop' },
  { id: '11', name: 'Rose', variety: "A Gardener's Dream Mattrae", category: PlantCategory.ORNAMENTAL, dateAdded: '2024-01-01', notes: 'Beautiful climber.', healthHistory: [], imageUrl: 'https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?q=80&w=1000&auto=format&fit=crop' },
  { id: '12', name: 'Laurus Nobilis', variety: 'Bay Tree', category: PlantCategory.HERB, dateAdded: '2024-01-01', notes: 'Culinary bay leaf.', healthHistory: [], imageUrl: 'https://images.unsplash.com/photo-1596708051772-0199e198754b?q=80&w=1000&auto=format&fit=crop' },
  { id: '13', name: 'Mondo Grass', variety: 'Ophiopogon Black', category: PlantCategory.GROUNDCOVER, dateAdded: '2024-01-01', notes: 'Striking black foliage.', healthHistory: [], imageUrl: 'https://images.unsplash.com/photo-1533038590840-1cde6e668a91?q=80&w=1000&auto=format&fit=crop' },
  { id: '14', name: 'Mondo Grass', variety: 'Curly', category: PlantCategory.GROUNDCOVER, dateAdded: '2024-01-01', notes: 'Textural groundcover.', healthHistory: [], imageUrl: 'https://images.unsplash.com/photo-1501004318641-b39e6451bec6?q=80&w=1000&auto=format&fit=crop' },
  { id: '15', name: 'Oregano', variety: 'True Greek', category: PlantCategory.HERB, dateAdded: '2024-01-01', notes: 'Essential herb.', healthHistory: [], imageUrl: 'https://images.unsplash.com/photo-1533150060955-460144c10650?q=80&w=1000&auto=format&fit=crop' },
  { id: '16', name: 'Lavender', variety: 'Major Improved', category: PlantCategory.HERB, dateAdded: '2024-01-01', notes: 'Aromatic and attracts bees.', healthHistory: [], imageUrl: 'https://images.unsplash.com/photo-1471943311424-646960669fbc?q=80&w=1000&auto=format&fit=crop' },
  { id: '17', name: 'Thyme', variety: 'Pizza', category: PlantCategory.HERB, dateAdded: '2024-01-01', notes: 'Great for cooking.', healthHistory: [], imageUrl: 'https://images.unsplash.com/photo-1502394202744-021cfbb17454?q=80&w=1000&auto=format&fit=crop' },
  { id: '18', name: 'Rosemary', variety: 'Gorizia', category: PlantCategory.HERB, dateAdded: '2024-01-01', notes: 'Large leafed, upright.', healthHistory: [], imageUrl: 'https://images.unsplash.com/photo-1515589172336-da3a7235c253?q=80&w=1000&auto=format&fit=crop' },
  { id: '19', name: 'Daphne', variety: 'Pimelea Flat White', category: PlantCategory.SHRUB, dateAdded: '2024-01-01', notes: 'New Zealand native daphne-like shrub.', healthHistory: [], imageUrl: 'https://images.unsplash.com/photo-1520412099561-64831cee0f37?q=80&w=1000&auto=format&fit=crop' },
];

export interface DetailedMonthlyGuide {
  month: number;
  title: string;
  focus: string;
  watering: string;
  pruning: string;
  fertilizing: string;
  planting: string;
  pests: string;
}

export const AUCKLAND_MONTHLY_GUIDE: DetailedMonthlyGuide[] = [
  { 
    month: 0, 
    title: 'January (Mid Summer)', 
    focus: 'Survival & Hydration', 
    watering: 'Deep soak every 2-3 days for Citrus (Meyer Lemon/Mandarin) and young Maples. Mulch Mondo grass to keep roots cool.',
    pruning: 'Deadhead Roses (Scentimental/Gardener\'s Dream) to keep them blooming. Trim Oregano/Thyme after flowering.',
    fertilizing: 'Citrus (Meyer Lemon/Mandarin) need a light summer feed now. Avoid fertilizing Daphne in extreme heat.',
    planting: 'Too hot for most. Only plant Mondo grass if shaded and kept very wet.',
    pests: 'Citrus Leaf Miner is peaking. Watch for distorted new growth on Lemons.'
  },
  { 
    month: 1, 
    title: 'February (Late Summer)', 
    focus: 'Harvest & Resilience', 
    watering: 'Critical for Stone Fruit (Nectarine/Plum/Cherry) as buds for next year are forming. Water Lavender at the base, not the leaves.',
    pruning: 'Prune Lavender (Major Improved) hard once flowering stops. Light trim for Rosemary.',
    fertilizing: 'Apply Seaweed tonic to Maples and Daphne to build heat tolerance.',
    planting: 'Prepare ground for Autumn roses. Dig in sheep pellets.',
    pests: 'Watch for Guava Moth in your Plum (Santa Rosa) and Nectarine (Mabel).'
  },
  { 
    month: 2, 
    title: 'March (Early Autumn)', 
    focus: 'Pre-Winter Nutrition', 
    watering: 'Moderate. Check soil under Maples; if too dry, they might drop leaves early.',
    pruning: 'Trim Oregano and Thyme back to keep them compact. Do not prune Daphne yet.',
    fertilizing: 'Final Citrus feed for the year. Feed Roses to support the final autumn flush.',
    planting: 'Excellent for Podocarpus (Yew Pine) and Mondo grass. Soil is warm and moisture is returning.',
    pests: 'Passionvine Hopper on Maples and Roses. Use a hose to blast them off.'
  },
  { 
    month: 3, 
    title: 'April (Mid Autumn)', 
    focus: 'Planting Season', 
    watering: 'Reduce if rain is consistent. Check pots for your Oregano/Thyme.',
    pruning: 'Remove any dead wood from Maples. Do not prune spring-fruiting Stone Fruits yet.',
    fertilizing: 'Stop nitrogen feeds for Maples and Acacia to allow wood to harden.',
    planting: 'Ideal for Nectarines, Plums, and Cherries. Best time to plant Daphne (Flat White).',
    pests: 'Slugs and snails active on Mondo grass with the return of humidity.'
  },
  { 
    month: 4, 
    title: 'May (Late Autumn)', 
    focus: 'Soil & Dormancy', 
    watering: 'Weekly watering for Citrus if rain fails. Minimal for Herbs.',
    pruning: 'Acacia Howittii can be shaped now. Remove messy growth from Indigo.',
    fertilizing: 'Apply garden lime to Lavender and Thyme areas (they love alkaline soil).',
    planting: 'Plant Garlic and Spring Bulbs. Plant your Bay tree (Laurus Nobilis) now.',
    pests: 'Leaf Spot on Roses. Clean up fallen rose leaves and bin them.'
  },
  { 
    month: 5, 
    title: 'June (Early Winter)', 
    focus: 'Dormancy Pruning', 
    watering: 'Only for pots. Maples and Stone Fruits are now dormant.',
    pruning: 'Main Prune for Nectarine (Mabel), Plum (Santa Rosa), and Cherry (Stella). Use clean, sharp tools.',
    fertilizing: 'Top dress Daphne with acidic compost. Avoid feeding the Herbs.',
    planting: 'Bare-root Roses and Fruit Trees. Add another Mandarin or Lemon now.',
    pests: 'Apply Copper spray to your Stone Fruits to prevent Leaf Curl next spring.'
  },
  { 
    month: 6, 
    title: 'July (Mid Winter)', 
    focus: 'Major Maintenance', 
    watering: 'Very minimal. Check Citrus for yellowing; may need a "trace element" spray.',
    pruning: 'Finish Stone Fruit pruning. Prune Maples while they are fully dormant.',
    fertilizing: 'Dormant feed: Blood and Bone around the base of trees.',
    planting: 'Move any plants that aren\'t thriving (e.g., if Lavender is too wet).',
    pests: 'Scale on Citrus. Use horticultural oil on a calm, dry winter day.'
  },
  { 
    month: 7, 
    title: 'August (Late Winter)', 
    focus: 'Bud Break Prep', 
    watering: 'Increase for Citrus as they prepare for bloom. Daphne is likely flowering now.',
    pruning: 'HARD PRUNE ROSES. Cut back to outward facing buds. Shape Bay Tree.',
    fertilizing: 'FEED CITRUS NOW. Feed Roses with high potash fertilizer.',
    planting: 'Last chance for bare-root trees. Plant new herbs as soil warms.',
    pests: 'Aphids appear on new growth of Roses and Citrus. Stay vigilant.'
  },
  { 
    month: 8, 
    title: 'September (Early Spring)', 
    focus: 'The Growth Rush', 
    watering: 'Regular. Don\'t let the new growth on your Maple dry out in wind.',
    pruning: 'Lightly trim Daphne after it finishes flowering. Prune Indigo to ground if needed.',
    fertilizing: 'EVERYTHING. General garden feed. Boost your Rosemary and Lavender.',
    planting: 'Citrus, Feijoa, and spring annuals. Plant more Oregano and Thyme.',
    pests: 'Bronze Beetle on Maples and Fruit trees. Look for "shotholes" in leaves.'
  },
  { 
    month: 9, 
    title: 'October (Mid Spring)', 
    focus: 'Active Growth', 
    watering: 'Establish a routine. Water roses at the root to prevent mildew.',
    pruning: 'Thin fruit on Nectarine/Plum if too dense. Tip prune Lavender for bushiness.',
    fertilizing: 'Second feed for Roses. Liquid seaweed for all young plants.',
    planting: 'Summer herbs and vegetables. Plant more Mondo grass for borders.',
    pests: 'Codling Moth in Apples/Pears. Use grease bands or pheromone traps.'
  },
  { 
    month: 10, 
    title: 'November (Late Spring)', 
    focus: 'Summer Transition', 
    watering: 'Deep soak twice weekly. Focus on Citrus and Maples.',
    pruning: 'Deadhead first flush of Roses. Trim Rosemary (Gorizia) if getting too big.',
    fertilizing: 'Side-dress fruit trees with compost. Feed Herbs to keep them lush.',
    planting: 'Final window for major tree planting before heat. Plant extra Lavender.',
    pests: 'Passionvine Hopper nymphs (small white fluffs) start appearing.'
  },
  { 
    month: 11, 
    title: 'December (Early Summer)', 
    focus: 'Hydration & Harvest', 
    watering: 'DAILY for pots. Deep soak for trees. Mulch Acacia to protect roots.',
    pruning: 'Prune Cherry (Stella) after harvest to manage size. Pinch back Herbs.',
    fertilizing: 'Final year-end feed for Citrus. Seaweed tonic for Maples.',
    planting: 'Summer annuals and heat-loving herbs like Oregano.',
    pests: 'Birds will take your Cherries and Plums! Net them now.'
  },
];
