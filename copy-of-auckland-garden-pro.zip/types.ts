
export enum PlantCategory {
  FRUIT = 'Fruit Trees',
  ORNAMENTAL = 'Ornamental',
  HERB = 'Herbs & Kitchen',
  SHRUB = 'Shrubs',
  GROUNDCOVER = 'Groundcover'
}

export type PlantCondition = 'Excellent' | 'Good' | 'Fair' | 'Poor';

export interface ConditionRecord {
  date: string;
  condition: PlantCondition;
  notes?: string;
}

export interface Plant {
  id: string;
  name: string;
  variety?: string;
  category: PlantCategory;
  dateAdded: string;
  lastFertilized?: string;
  lastPruned?: string;
  imageUrl?: string;
  notes: string;
  // History is now only accessed via Health context
  healthHistory: ConditionRecord[];
}

export interface DiagnosticResult {
  identification: string;
  problem: string;
  solution: string;
  urgency: 'Low' | 'Medium' | 'High';
}
